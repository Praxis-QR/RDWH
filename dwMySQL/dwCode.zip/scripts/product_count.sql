/*********************************************************************/
/*                                                                   */
/* product_count.sql                                                 */                  
/*                                                                   */
/*********************************************************************/

USE dw;

CREATE TABLE product_count_fact
( product_sk INT
, product_launch_date_sk INT )
;

/* end of script                                                     */


