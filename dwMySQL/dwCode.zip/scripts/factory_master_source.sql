/*********************************************************************/
/*                                                                   */
/* factory_master_source.sql                                         */                  
/*                                                                   */
/*********************************************************************/

USE source;

INSERT INTO factory_master VALUES
  ( 1, 'First Factory', '11111 Lichtman St.', 17050, 'Mechanicsburg', 'PA' )
, ( 2, 'Second Factory', '22222 Stobosky Ave.', 17055, 'Pittsburgh', 'PA' )
, ( 3, 'Third Factory', '33333 Fritze Rd.', 17050, 'Mechanicsburg', 'PA' )
, ( 4, 'Fourth Factory', '44444 Jenzen Blvd.', 17055, 'Pittsburgh', 'PA' )
;

