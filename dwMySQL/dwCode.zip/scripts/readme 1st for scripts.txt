Unzip the scripts.zip into C:\mysql\scripts,
where C:\mysql is your MySQL installation directory.
Depending on your MySQL installation, 
you might have to create the scripts sub-directory
(if your MySQL installation does not create it).