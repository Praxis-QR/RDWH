Unzip the data.zip into the C:\mysql\data\dw sub-directory. 
C:\mysql is your MySQL server installation directory.

Use Notepad to open a csv file. Do not use Microsoft Excel.

See instructions in Appendix B to use these flat files source data correctly.